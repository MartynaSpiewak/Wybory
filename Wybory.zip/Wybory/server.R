library(shiny)
library(ggplot2)
library(gridExtra)
library(dplyr)
library(stringi)
library(scales)
library(Hmisc)


shinyServer(function(input, output) {
  
  
  #twitter  - tabele
  tab_nasluch <- read.csv2("data/Podsumowanie_nasluch_kandydatow.csv")
  
  tab_nasluch_miesiac <- read.csv2("data/Podsumowanie_nasluch_kandydatow_miesiace.csv")
  
  tab_sentyment <- read.csv2("data/Podsumowanie_tweetow.csv")
  
  frame_posts <- read.table("Facebook/Posty/facebook_posts.csv", sep =";", h = T)
  
  # tableka inforamacyjna, w ktorej sa imiona i nazwiska wszystkich kandydatow i id
  
  can <- read.table("Facebook/kandydaci.csv", h = T)
  # podsumowanie likow
  
  frame_likes <- read.table("Facebook/Likes/Podsumowanie/Podsumowanie.csv", 
                            sep=";", header = TRUE)

  
  #popularnosc na twitterze
  
  output$wykres_popularnosc <- renderPlot({
    
    tweety_generuj_wykres(frame=tab_nasluch,name=input$kandydat,type=input$typ_wykresu_twitter,begin=input$data[1], end=input$data[2])
    
  })
  
  #aktywnosc na twitterze
  
  output$wykres_aktywnosc <- renderPlot({
    
    tweety_generuj_wykres(frame=tab_nasluch,name=input$kandydat,type="liczba tweetow",begin=input$data[1], end=input$data[2])
  })
  
  output$wykres_sentyment <- renderPlot({
    
    nazwiska <- unique(c(input$kandydat, input$wybor))
    d1 <- as.character(input$data[1])
    d2 <- as.character(input$data[2])
   sentyment_wykres(tab_sentyment,name=nazwiska, begin=d1, end=d2)
    
            
  })
  
  
  #podsumowanie miesieczne:
  
  output$wykres_popularnosc_miesiac <- renderPlot({
    
    nazwiska <- unique(c(input$kandydat, input$wybor))
    d1 <- as.character(input$data[1])
    d2 <- as.character(input$data[2])
    tweety_generuj_slupki(frame=tab_nasluch_miesiac,name=nazwiska,type=input$typ_wykresu_twitter,begin=d1, end=d2)
    
  })
  
  #facebook
  
  output$wykres_like_facebook <- renderPlot({
    
    nazwiska <- unique(c(input$kandydat, input$wybor))
    
    d1 <- as.character(input$data[1])
    d2 <- as.character(input$data[2])
    
    tmp <- facebook_like_w_czasie(nazwiska, frame_likes = frame_likes,from=d1, to=d2, can = can)
                                   ggplot(tmp, aes(x=data, y=likes, colour=name)) +
                                     geom_line(size = 1) + theme(legend.position="bottom") + 
                                     ggtitle("Count of likes per day")
    
  })
  
  output$wykres_like_roznica_facebook <- renderPlot({
    
    nazwiska <- unique(c(input$kandydat, input$wybor))
    
    d1 <- as.character(input$data[1])
    d2 <- as.character(input$data[2])
    
    resf3 <- facebook_like_roznice_w_czasie(nazwiska, from=d1, to=d2, frame_likes = frame_likes, can = can)
    
    ggplot(resf3, aes(x=data, y=diff_likes, colour=name)) +
      geom_line(size = 1) + theme(legend.position="bottom") + 
      ggtitle(paste0("Przyrost liczby polubien oficjalnych stron kandydatow w czasie ", "\n")) +
      theme(plot.title = element_text(lineheight=1.2, size = 14, face="bold")) +
      labs(x="", y="Likes")
    
  })
  
  
  output$wykres_post_facebook <- renderPlot({
    
    nazwiska <- unique(c(input$kandydat, input$wybor))
    
    d1 <- input$data[1]
    d2 <- input$data[2]
    
    resf4 <- facebook_post_ile_dziennie(nazwiska,
                                        frame_posts = frame_posts, can = can, from=d1, to=d2)
    
    if(input$typ_wykresu_facebook=="Liczba postow"){
      
      p <- ggplot(resf4, aes(x=date, y=posts_count, colour=name)) +ggtitle("Liczba postow")
        
    }
    
    if(input$typ_wykresu_facebook=="Srednia liczba polubien postow"){
      
      p <- ggplot(resf4, aes(x=date, y=likes_count, colour=name)) +ggtitle("Srednia liczba polubien postow")
      
    }
    
    if(input$typ_wykresu_facebook=="Srednia liczba komentarzy"){
      
      p <- ggplot(resf4, aes(x=date, y=comments_count, colour=name)) +ggtitle("Srednia liczba komentarzy")
      
    }
    
    if(input$typ_wykresu_facebook=="Srednia liczba udostepnien postow"){
      
      p <- ggplot(resf4, aes(x=date, y=shares_count, colour=name)) +ggtitle("Srednia liczba udostepnien postow")
      
    }
    
    
    p + geom_line(size = 1) + theme(legend.position="bottom") + 
      theme(plot.title = element_text(lineheight=1.2, size = 14, face="bold"))
    
  })
  
  output$wykres_like_oficjalne <- renderPlot({
    
    nazwiska <- unique(c(input$kandydat, input$wybor))
    res <- facebook_like_najlepszy_wynik(input$data[1], frame_likes = frame_likes, can = can)
    
    k <- which(res$name%in%nazwiska)
    
    res <- res[k,]
    
    ggplot(res, aes(x = factor(name), y = likes)) + geom_bar(stat = "identity") 
    
  })

  
})
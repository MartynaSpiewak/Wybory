library(shiny)
library(ggplot2)
library(gridExtra)
library(dplyr)
library(stringi)
library(scales)
library(data.table)



shinyUI(
  shinyUI(navbarPage("My Application",
                     tabPanel("HomePage",
                              titlePanel("Analiza widoczności kandydatów na prezydenta"),
                              selectInput("kandydat",label="Kandydat",choices=c("Bronislaw Komorowski","Andrzej Duda","Adam Jarubas",
                                                                                "Janusz Korwin Mikke","Marian Kowalski","Pawel Kukiz",
                                                                                "Magdalena Ogorek","Janusz Palikot"),selected="Bronislaw Komorowski"),
                              checkboxGroupInput(inputId = "wybor",label = "Porownanie:",
                                                 choices = c("Bronislaw Komorowski","Andrzej Duda","Adam Jarubas",
                                                             "Janusz Korwin Mikke","Marian Kowalski","Pawel Kukiz",
                                                             "Magdalena Ogorek","Janusz Palikot")),
                              dateRangeInput("data",label="Analizowany okres czasu", start="2015-03-18",end="2015-05-10"),
                              mainPanel(
                                )),
                     
                     
                     tabPanel("Twitter",
                              fluidPage(
                                titlePanel("Analiza danych z twittera."),
                                sidebarLayout(
                                  sidebarPanel(
                                    selectInput("typ_wykresu_twitter",
                                                "Popularnosc - typ wykresu",
                                                c("srednio retweetow", "suma retweetow", "srednio like","suma like"),
                                                "srednio retweetow")
                                    ),
                              mainPanel(
                                tabsetPanel(
                                  tabPanel("Analiza sentymentu", plotOutput("wykres_sentyment",width=700,height=500)),
                                  tabPanel("Popularność wśród użytkowników",plotOutput("wykres_popularnosc", width = 500,height=400)),
                                  tabPanel("Aktywność na twitterze",plotOutput("wykres_aktywnosc", width = 500, height=400)),
                                  tabPanel("Popularnosc wsrod uzytkownikow - podsumowanie miesieczne",plotOutput("wykres_popularnosc_miesiac",width=600,height=500))
                                  
                                ))))),
                     tabPanel("Facebook",
                              fluidPage(
                                titlePanel("Analiza danych z facebooka"),
                                sidebarLayout(
                                  sidebarPanel(
                                    selectInput("typ_wykresu_facebook", "Analiza postow - typ wykresu",
                                                choices=c("Liczba postow","Srednia liczba polubien postow","Srednia liczba komentarzy",
                                                          "Srednia liczba udostepnien postow"),selected="Liczba postow"
                                      )),
                                  mainPanel(
                                    tabsetPanel(
                                      tabPanel("Like", plotOutput("wykres_like_facebook",width=500)),
                                      tabPanel("Like - roznica w czasie", plotOutput("wykres_like_roznica_facebook",width=500)),
                                      tabPanel("Like - liczba polubien oficjalnych stron",  plotOutput("wykres_like_oficjalne",width=500)),
                                      tabPanel("Analiza postow", plotOutput("wykres_post_facebook",width=500))
                                      
                                  ))
                             
                     )
                     
  ))
)))